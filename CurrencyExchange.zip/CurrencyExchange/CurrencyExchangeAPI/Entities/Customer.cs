﻿using System;
using CurrencyExchangeAPI.Entities.Common;

namespace CurrencyExchangeAPI.Entities
{
    public class Customer : BaseEntity
    {
        public string Name { get; set; } = string.Empty;

        public string? MiddleName { get; set; }

        public string LastName { get; set; } = string.Empty;
    }
}

    