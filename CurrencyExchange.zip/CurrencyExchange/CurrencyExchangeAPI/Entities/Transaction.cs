﻿using System;
using CurrencyExchangeAPI.Entities.Common;
using Microsoft.EntityFrameworkCore;

namespace CurrencyExchangeAPI.Entities
{
    [Index(nameof(CustomerId))]
    [Index(nameof(CustomerId), nameof(InsertDate))]
    public class Transaction : BaseEntity
    {
        public int CustomerId { get; set; }

        public string From { get; set; } = string.Empty;

        public string To { get; set; } = string.Empty;

        public decimal Amount { get; set; } = 0;

        public decimal DestinationAmount { get; set; } = 0;

        public string ExchangeRateDate { get; set; } = string.Empty;
    }
}

