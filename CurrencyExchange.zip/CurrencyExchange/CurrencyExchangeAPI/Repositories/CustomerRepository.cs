﻿using System;
using CurrencyExchangeAPI.Contexts;
using CurrencyExchangeAPI.Controllers;
using CurrencyExchangeAPI.Entities;
using Microsoft.Extensions.Caching.Memory;

namespace CurrencyExchangeAPI.Repositories
{
    public class CustomerReadRepository : ReadRepository<Customer>, ICustomerReadRepository
    {
        public CustomerReadRepository(CurrencyExcDbContext context, ILogger<TransactionController> logger, IMemoryCache memoryCache) : base(context, logger, memoryCache)
        {
        }
    }

    public class CustomerWriteRepository : WriteRepository<Customer>, ICustomerWriteRepository
    {
        public CustomerWriteRepository(CurrencyExcDbContext context, ILogger<TransactionController> logger, IMemoryCache memoryCache) : base(context, logger, memoryCache)
        {
        }
    }
}

