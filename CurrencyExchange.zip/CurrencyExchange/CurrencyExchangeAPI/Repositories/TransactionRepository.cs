﻿using System;
using CurrencyExchangeAPI.Contexts;
using CurrencyExchangeAPI.Controllers;
using CurrencyExchangeAPI.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace CurrencyExchangeAPI.Repositories
{
    public class TransactionReadRepository : ReadRepository<Transaction>, ITransactionReadRepository
    {
        private readonly CurrencyExcDbContext _context;
        readonly ILogger<TransactionController> _logger;
        public TransactionReadRepository(CurrencyExcDbContext context, ILogger<TransactionController> logger, IMemoryCache memoryCache) : base(context, logger, memoryCache)
        {
            _context = context;
            _logger = logger;
        }

        public List<Transaction> GetByCustomerId(int customerId)
        {
            return  _context.Set<Transaction>().Where(x => x.CustomerId == customerId).ToList();
        }

        public List<Transaction> GetByCustomerIdAndInsertDate(int customerId, DateTime insertDate)
        {
            return _context.Set<Transaction>().Where(x => x.CustomerId == customerId && x.InsertDate.Date == insertDate.Date).ToList();
        }
    }

    public class TransactionWriteRepository : WriteRepository<Transaction>, ITransactionWriteRepository
    {
        public TransactionWriteRepository(CurrencyExcDbContext context, ILogger<TransactionController> logger, IMemoryCache memoryCache) : base(context, logger, memoryCache)
        {
        }
    }
}

