﻿using System;
using System.Collections.Generic;
using CurrencyExchangeAPI.Contexts;
using CurrencyExchangeAPI.Controllers;
using CurrencyExchangeAPI.Entities.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Caching.Memory;
using Newtonsoft.Json;

namespace CurrencyExchangeAPI.Repositories
{
    public class ReadRepository<T> : IReadRepository<T> where T : BaseEntity
    {
        private readonly CurrencyExcDbContext _context;
        readonly ILogger<TransactionController> _logger;
        readonly IMemoryCache _memoryCache;
        string cacheKey = "currencyExchangeCacheKey" + typeof(T).FullName;

        public ReadRepository(CurrencyExcDbContext context, ILogger<TransactionController> logger, IMemoryCache memoryCache)
        {
            _context = context;
            _logger = logger;
            _memoryCache = memoryCache;
        }

        public DbSet<T> Table => _context.Set<T>();        

        public IEnumerable<T> GetAll()
        {
            if (!_memoryCache.TryGetValue(cacheKey, out IEnumerable<T> entityList))
            {
                // If memory has not value then retrieve data from database and set cache.
                entityList = Table.ToList();

                var cacheOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpiration = DateTime.Now.AddMinutes(5),
                    Priority = CacheItemPriority.Normal
                };

                _memoryCache.Set(cacheKey, entityList, cacheOptions);

                _logger.LogInformation("List has been retrieved from database.");
            }
            else
            {
                _logger.LogInformation("List has been retrieved from cache.");
            }

            _logger.LogInformation("Called GET method.");

            return entityList;
        }

        public async Task<T> GetByIdAsync(int id)
        {
            _logger.LogInformation("Called GET method (by id). Id: " + id);

            //var path = Path.GetDirectoryName(Environment.CurrentDirectory);
            //var fullPath = path + "/Log.txt";
            //using (var sw = new StreamWriter(fullPath, true))
            //{
            //    sw.WriteLine("Test");
            //    sw.Close();
            //}

            return await Table.FindAsync(id);
        }
    }

    public class WriteRepository<T> : IWriteRepository<T> where T : BaseEntity
    {
        private readonly CurrencyExcDbContext _context;
        readonly ILogger<TransactionController> _logger;
        readonly IMemoryCache _memoryCache;
        string cacheKey = "currencyExchangeCacheKey" + typeof(T).FullName;

        public WriteRepository(CurrencyExcDbContext context, ILogger<TransactionController> logger, IMemoryCache memoryCache)
        {
            _context = context;
            _logger = logger;
            _memoryCache = memoryCache;
        }

        public DbSet<T> Table => _context.Set<T>();

        public async Task<bool> AddAsync(T model)
        {
            EntityEntry<T> entityEntry = await Table.AddAsync(model);

            if (entityEntry.State == EntityState.Added)
            {
                _logger.LogInformation("Inserted. " + JsonConvert.SerializeObject(model));
            }
            else
            {
                _logger.LogInformation("An error occured while inserting. " + JsonConvert.SerializeObject(model));
            }

            CleanCache(cacheKey);

            return entityEntry.State == EntityState.Added;
        }

        public bool Remove(T model)
        {
            var result = Table.Remove(model);

            _context.Entry<T>(model).State = EntityState.Deleted;

            if (result.State == EntityState.Added)
            {
                _logger.LogInformation("Deleted. " + JsonConvert.SerializeObject(model));
            }
            else
            {
                _logger.LogInformation("An error occured while deleting. " + JsonConvert.SerializeObject(model));
            }

            CleanCache(cacheKey);

            return result.State == EntityState.Deleted;
        }

        public async Task<int> SaveAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public bool Update(T model)
        {
            model.UpdateDate = DateTime.Now;

            _context.Entry(model).State = EntityState.Detached;

            var result = Table.Update(model);

            if (result.State == EntityState.Modified)
            {
                _logger.LogInformation("Updated. " + JsonConvert.SerializeObject(model));
            }
            else
            {
                _logger.LogInformation("An error occured while updating. " + JsonConvert.SerializeObject(model));
            }

            CleanCache(cacheKey);

            return result.State == EntityState.Modified;
        }

        void CleanCache(string key)
        {
            _memoryCache.Remove(cacheKey);
            _logger.LogInformation("Cache cleaned. Cache Key: " + cacheKey);
        }
    }
}

