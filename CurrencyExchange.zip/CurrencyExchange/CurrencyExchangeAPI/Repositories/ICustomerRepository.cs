﻿using System;
using CurrencyExchangeAPI.Entities;

namespace CurrencyExchangeAPI.Repositories
{
    public interface ICustomerReadRepository : IReadRepository<Customer>
    {
    }
    
    public interface ICustomerWriteRepository : IWriteRepository<Customer>
    {
    }
}

