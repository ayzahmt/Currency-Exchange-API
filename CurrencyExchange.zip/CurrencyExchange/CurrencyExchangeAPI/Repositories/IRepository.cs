﻿using System;
using Microsoft.EntityFrameworkCore;
using CurrencyExchangeAPI.Entities.Common;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace CurrencyExchangeAPI.Repositories
{
    public interface IRepository<T> where T : BaseEntity
    {
        DbSet<T> Table { get; }
    }

    public interface IWriteRepository<T> : IRepository<T> where T : BaseEntity
    {
        Task<bool> AddAsync(T model);

        bool Remove(T model);

        bool Update(T model);

        Task<int> SaveAsync();
    }


    public interface IReadRepository<T> : IRepository<T> where T : BaseEntity
    {
        IEnumerable<T> GetAll();

        Task<T> GetByIdAsync(int id);
    }
}

