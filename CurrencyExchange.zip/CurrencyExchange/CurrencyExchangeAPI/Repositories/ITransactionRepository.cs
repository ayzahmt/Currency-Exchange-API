﻿using System;
using CurrencyExchangeAPI.Entities;

namespace CurrencyExchangeAPI.Repositories
{
    public interface ITransactionReadRepository : IReadRepository<Transaction>
    {
        List<Transaction> GetByCustomerId(int customerId);

        List<Transaction> GetByCustomerIdAndInsertDate(int customerId, DateTime insertDate);
    }

    public interface ITransactionWriteRepository : IWriteRepository<Transaction>
    {
    }
}

