﻿using System.Diagnostics.Contracts;
using System.Net;
using CurrencyExchangeAPI.Entities;
using CurrencyExchangeAPI.Helper;
using CurrencyExchangeAPI.Repositories;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace CurrencyExchangeAPI.Controllers;

[ApiController]
[Route("[controller]")]
public class TransactionController : ControllerBase
{
    readonly ITransactionReadRepository _transactionReadRepository;
    readonly ITransactionWriteRepository _transactionWriteRepository;
    readonly ICustomerReadRepository _customerReadRepository;
    readonly IConfiguration _configuration;
    readonly ILogger<TransactionController> _logger;

    public TransactionController(ITransactionReadRepository transactionReadRepository,
                              ITransactionWriteRepository transactionWriteRepository,
                              ICustomerReadRepository customerReadRepository,
                              IConfiguration configuration,
                              ILogger<TransactionController> logger)
    {
        _transactionReadRepository = transactionReadRepository;
        _transactionWriteRepository = transactionWriteRepository;
        _customerReadRepository = customerReadRepository;
        _configuration = configuration;
        _logger = logger;
    }

    [HttpGet("[action]/{id}")]
    public async Task<Transaction> GetById(int id)
    {
        return await _transactionReadRepository.GetByIdAsync(id);
    }

    [HttpGet("[action]")]
    public List<Transaction> GetAll()
    {
        return _transactionReadRepository.GetAll().ToList();
    }

    [HttpGet("[action]")]
    public async Task<IActionResult> Insert(Transaction contract)
    {
        #region Check if customer can trade
        var customer = await _customerReadRepository.GetByIdAsync(contract.CustomerId);
        if (customer == null)
        {
            return new CustomError(HttpStatusCode.OK, $"Customer not found. Customer No: {contract.CustomerId}");
        }

        var transactionList = _transactionReadRepository.GetByCustomerIdAndInsertDate(contract.CustomerId, DateTime.Today);

        if (transactionList.Count() >= 10)
        {
            var lastOneHourRecords = transactionList.Where(x => x.InsertDate > DateTime.Now.AddMinutes(-60)).ToList();

            if (lastOneHourRecords.Count() >= 10)
            {
                return new CustomError(HttpStatusCode.OK, $"Could not trade. Max limit is 10 per hour. Customer No: {contract.CustomerId}");
            }
        }
        #endregion

        var currencyController = new CurrencyExchangeController(_configuration);
        var response = currencyController.GetConvert(new Query
        {
            Amount = contract.Amount,
            From = contract.From,
            To = contract.To,
            Date = contract.ExchangeRateDate            
        });

        if (response.Result.Success == "false")
        {            
            return new CustomError(HttpStatusCode.NoContent, $"Success: {response.Result.Success} ");
        }

        if (response.Result == null)
        {
            return new CustomError(HttpStatusCode.NoContent, $"Could not find Currency Info on fixer.io. Parameters: From: {contract.From} To: {contract.To}");
        }

        #region Check if exchange rate time is older than 30 minutes
        long timestamp = long.Parse(response.Result.Info.Timestamp);

        var dateTime = DateTimeOffset.FromUnixTimeSeconds(timestamp).LocalDateTime;

        if (dateTime < DateTime.Now.AddMinutes(-30))
        {
            return new CustomError(HttpStatusCode.OK,
                                    $"Exchange rate is used it should never be older than 30 minutes. " +
                                    $"Parameters: From: {contract.From} To: {contract.To} ExchangeRateDate: {contract.ExchangeRateDate}");
        }
        #endregion

        contract.DestinationAmount = response.Result.Result;
        contract.ExchangeRateDate = response.Result.Date;

        try
        {
            await _transactionWriteRepository.AddAsync(contract);

            await _transactionWriteRepository.SaveAsync();
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return Ok();
    }

    [HttpGet("[action]")]
    public void Delete(Transaction contract)
    {
        _transactionWriteRepository.Remove(contract);

        _transactionWriteRepository.SaveAsync();
    }

    [HttpGet("[action]")]
    public ActionResult Update(Transaction contract)
    {
        try
        {
            _transactionWriteRepository.Update(contract);

            _transactionWriteRepository.SaveAsync();
        }
        catch (Exception ex)
        {
            throw ex;
        }


        return Ok();
    }
}

