﻿using System.Diagnostics.Contracts;
using CurrencyExchangeAPI.Entities;
using CurrencyExchangeAPI.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace CurrencyExchangeAPI.Controllers;

[ApiController]
[Route("[controller]")]
public class CustomerController : ControllerBase
{
    readonly ICustomerReadRepository _customerReadRepository;
    readonly ICustomerWriteRepository _customerWriteRepository;
    readonly ILogger<CustomerController> _logger;

    public CustomerController(ICustomerReadRepository customerReadRepository,
                              ICustomerWriteRepository customerWriteRepository,
                              ILogger<CustomerController> logger)
    {
        _customerReadRepository = customerReadRepository;
        _customerWriteRepository = customerWriteRepository;
        _logger = logger;
    }

    [HttpGet("[action]/{id}")]
    public async Task<Customer> GetById(int id)
    {
        return await _customerReadRepository.GetByIdAsync(id);
    }

    [HttpGet("[action]")]
    public List<Customer> GetAll()
    {
        return _customerReadRepository.GetAll().ToList();
    }

    [HttpGet("[action]")]
    public async Task Insert(Customer contract)
    {
        await _customerWriteRepository.AddAsync(contract);

        await _customerWriteRepository.SaveAsync();
    }

    [HttpGet("[action]")]
    public void Delete(Customer contract)
    {
        _customerWriteRepository.Remove(contract);  
            
        _customerWriteRepository.SaveAsync();
    }

    [HttpGet("[action]")]
    public ActionResult Update(Customer contract)
    {
        try
        {
            _customerWriteRepository.Update(contract);

            _customerWriteRepository.SaveAsync();
        }
        catch (Exception ex)
        {
            throw ex;
        }


        return Ok();
    }
}

