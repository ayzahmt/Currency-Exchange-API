﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;

namespace CurrencyExchangeAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CurrencyExchangeController : ControllerBase
    {
        readonly IConfiguration _configuration;
        public CurrencyExchangeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet("[action]")]
        public async Task<ConvertContract> GetConvert(Query query)
        {
            string key = _configuration.GetValue<string>("ApiKey");
            string baseUri = _configuration.GetValue<string>("Url"); 

            var httpClient = new HttpClient();

            httpClient.DefaultRequestHeaders.Add("ApiKey", key);

            string url = $"{baseUri}" +
                         $"?to={query.To}" +
                         $"&from={query.From}" +
                         $"&amount={query.Amount}" +
                         $"&date={query.Date}";

            var response = await httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();
            string result = await response.Content.ReadAsStringAsync();
            ConvertContract value = JsonConvert.DeserializeObject<ConvertContract>(result);

            return value;
        }        
    }

    public class ConvertContract
    {
        public string Success { get; set; }
        public Query Query { get; set; }
        public Info Info { get; set; }
        public string Date { get; set; }
        public decimal Result { get; set; }
    }

    public class Query
    {
        public string From { get; set; }
        public string To { get; set; }
        public decimal Amount { get; set; }
        public string Date { get; set; }
    }

    public class Info
    {
        public string Timestamp { get; set; }
        public decimal Rate { get; set; }        
    }
}

