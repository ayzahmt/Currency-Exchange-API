﻿using System;
using CurrencyExchangeAPI.Entities;
using System.Net;
using Microsoft.EntityFrameworkCore;

namespace CurrencyExchangeAPI.Contexts
{
    public class CurrencyExcDbContext : DbContext
    {
        public CurrencyExcDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Customer> Customer { get; set; }
        public DbSet<Transaction> Transaction { get; set; }
    }
}

