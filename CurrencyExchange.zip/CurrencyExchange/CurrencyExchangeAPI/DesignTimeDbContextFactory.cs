﻿using System;
using CurrencyExchangeAPI.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace CurrencyExchangeAPI
{
    /// <summary>
    ///     Migration yaparken DbContext nesnesi oluşturulamadığı için
    ///     bu configuration yapıldı
    /// </summary>
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<CurrencyExcDbContext>
    {

        public CurrencyExcDbContext CreateDbContext(string[] args)
        {
            DbContextOptionsBuilder<CurrencyExcDbContext> dbContextOptionsBuilder = new();

            dbContextOptionsBuilder.UseSqlServer(Configuration.ConnectionString);

            return new CurrencyExcDbContext(dbContextOptionsBuilder.Options);
        }
    }
}

