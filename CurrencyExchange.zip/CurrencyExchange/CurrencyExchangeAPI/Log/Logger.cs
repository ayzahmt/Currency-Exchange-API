﻿using System;
using Microsoft.Extensions.Logging;

namespace CurrencyExchangeAPI.Log
{
    public class Logger : ILogger
    {
        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {            
            var message = $"{logLevel.ToString()}: {DateTime.Now} {eventId.Name} - {formatter(state, exception)}";

            WriteToFile(message);
        }

        void WriteToFile(string message)
        {
            var path = Path.GetDirectoryName(Environment.CurrentDirectory);
            var fullPath = path + "/Log.txt";
            using (var sw = new StreamWriter(fullPath, true))
            {
                sw.WriteLine(message);
                sw.Close();
            }
        }
    }
}

